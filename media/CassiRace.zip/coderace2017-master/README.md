# coderace2017
CODERACE 2017 

### Pacotes necessários:
```
python3
python3-pip
```
### Execução:
```
$pip3 install -r requirements.txt
$python3 manage.py makemigrations
$python3 manage.py migrate
$python3 manage.py runserver
```

Depois acesse o endereço http://127.0.0.1:8000
