from django.contrib import admin

# Register your models here.
from .models import Profile, Empresa, Cargo, Modules

admin.site.register(Profile)
admin.site.register(Empresa)
admin.site.register(Modules)


class CargoAdmin(admin.ModelAdmin):
    list_display = ['profile', 'empresa', 'cargo']
    search_fields = ['empresa', 'cargo', 'profile']
    list_filter = ['cargo', 'empresa']

admin.site.register(Cargo, CargoAdmin)