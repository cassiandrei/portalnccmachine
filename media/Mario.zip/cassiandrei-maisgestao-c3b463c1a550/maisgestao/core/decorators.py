from django.core.exceptions import PermissionDenied

from core.models import Cargo, Profile, Empresa
from django.core.exceptions import ObjectDoesNotExist


def secure_slug(f):
    def verifica(request, *args, **kwargs):
        empresa = Empresa.objects.get(slug=kwargs['slug'])
        profile = Profile.objects.get(user=request.user)
        try:
            Cargo.objects.get(empresa=empresa, profile=profile, cargo='owner')
        except ObjectDoesNotExist:
            raise PermissionDenied

        return f(request, *args, **kwargs)

    verifica.__doc__ = f.__doc__
    verifica.__name__ = f.__name__
    return verifica
