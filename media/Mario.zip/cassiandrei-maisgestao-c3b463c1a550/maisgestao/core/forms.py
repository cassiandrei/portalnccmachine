from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm

from core.models import Empresa, Profile

from maisgestao.settings import MODULOS


class SignUpForm(UserCreationForm):
    telefone = forms.CharField(max_length=15)

    class Meta:
        model = User
        fields = ('username', 'email', 'telefone', 'password1', 'password2',)


class EmpresaForm(ModelForm):
    class Meta:
        model = Empresa
        fields = ('nome', 'slug', 'telefone', 'email', 'saldo', 'cidade', 'rua', 'numero', 'complemento')


class EmpresaEdicaoForm(ModelForm):
    class Meta:
        model = Empresa
        fields = ('nome', 'telefone', 'email', 'site', 'cidade', 'rua', 'numero', 'complemento', 'file')


class UserEdicaoForm(ModelForm):
    username = forms.CharField(max_length=40)
    email = forms.CharField(max_length=40)

    class Meta:
        model = Profile
        fields = ('username', 'email', 'telefone', 'picture')
