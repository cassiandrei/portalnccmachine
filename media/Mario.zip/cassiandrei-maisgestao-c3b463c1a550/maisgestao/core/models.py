from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

from maisgestao.settings import MODULOS, CARGOS, BASE_DIR


def user_directory_path():
    pass


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    telefone = models.CharField(max_length=15)
    authNumber = models.IntegerField(default=0)

    @receiver(post_save, sender=User)
    def update_user_profile(sender, instance, created, **kwargs):
        if created:
            Profile.objects.create(user=instance)
        instance.profile.save()

    def arquivoname(self, filename):
        return str(self.user.username) + '.' + filename.split('.')[-1]

    picture = models.FileField(upload_to=arquivoname)

    def __str__(self):
        return self.user.username


class Empresa(models.Model):
    nome = models.CharField(max_length=200, verbose_name='Nome do negócio*')
    slug = models.SlugField(max_length=20, unique=True, verbose_name='Identificador',
                            help_text="Identificador para o seu negócio, exemplo: mgestao")
    telefone = models.CharField(max_length=15, verbose_name='Telefone principal para contato*')
    email = models.EmailField(unique=True, verbose_name='Email para contato*')
    site = models.CharField(max_length=100, blank=True)
    cidade = models.CharField(max_length=30, blank=True)
    rua = models.CharField(max_length=30, blank=True)
    numero = models.CharField(max_length=6, blank=True)
    complemento = models.CharField(max_length=30, blank=True)
    diaria = models.IntegerField(default=15)
    saldo = models.IntegerField(default=0, help_text='Saldo inicial em caixa')
    membros = models.ManyToManyField(Profile, through='Cargo')

    def arquivoname(self, filename):
        return str(self.slug) + '.' + filename.split('.')[-1]

    file = models.FileField(upload_to=arquivoname, null=True)

    def __str__(self):
        return self.nome


class Modules(models.Model):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    module = models.CharField(max_length=30, choices=MODULOS)

    def __str__(self):
        return self.empresa.nome + '|' + self.module


class Cargo(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    cargo = models.CharField(max_length=30, blank=True, choices=CARGOS)

    def __str__(self):
        return "%s na empresa %s" % (self.cargo.title(), self.empresa.nome.title())


class Cliente(models.Model):
    STATUS = (
        ('ativo', 'Ativo'),
        ('trancado', 'Trancado'),
        ('inativo', 'Inativo'),
        ('pendente', 'Pendente'),
    )

    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    nome = models.CharField(max_length=75, verbose_name='Nome Completo')
    cpf = models.CharField(max_length=11, verbose_name='Cadastro de Pessoa Física')
    telefone = models.CharField(max_length=15, verbose_name='Telefone para Contato')
    email = models.EmailField(max_length=254)
    status = models.CharField(max_length=10, choices=STATUS, default='pendente')

    created = models.DateTimeField('Criado em', auto_now_add=True)
    modified = models.DateTimeField('Modificado em', auto_now=True)

    class Meta:
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'
        unique_together = ('cpf', 'empresa')

    def __str__(self):
        return self.empresa.nome + '|' + self.nome
