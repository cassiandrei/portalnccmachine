from django.conf import settings
from django.conf.urls import url
from django.conf.urls.static import static
from core import views

urlpatterns = [
                  url(r'^$', views.index, name='index'),
                  url(r'^portal/$', views.portal, name='portal'),
                  url(r'^conta/$', views.criarconta, name='criarconta'),
                  url(r'^sitemap/$', views.sitemap, name='sitemap'),
                  url(r'^contato/$', views.contato, name='contato'),
                  url(r'^criar-empresa/$', views.criarempresa, name='criar_empresa'),
                  url(r'^editar-empresa/(?P<slug>[\w_-]+)/$', views.editarempresa, name='editar_empresa'),
                  url(r'^empresa/(?P<slug>[\w_-]+)/$', views.empresa, name='empresa'),
                  url(r'^editar-user/$', views.editaruser, name='editar_user'),

                  # url(r'^esqueci-senha/$', views.esquecisenha, name='esqueci_senha'),
                  url(r'^gen-token/$', views.gentoken, name='gen_token'),
                  url(r'^auth/(?P<token>[0-9]+)$', views.auth, name='auth_token'),
                  url(r'^settings/$', views.settings, name='settings'),

                  url(r'^send-email/$', views.sendEmail, name='send_email')

              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
