from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth import authenticate, login
from django.core.mail import send_mail
from django.core.urlresolvers import reverse
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render, redirect
from django.contrib import messages

from core.apps import recaptcha
from core.forms import *
from core.models import Cargo, Profile, Empresa, Modules

from maisgestao.settings import MODULOS, LOCAL

import pyotp
import random
import string


def index(request):
    return render(request, 'core/index.html')


@login_required
def portal(request):
    empresas = Cargo.objects.filter(profile=Profile.objects.get(user=request.user))
    context = {
        'empresas': empresas,
        'MODULOS': MODULOS,
        'VOLTAR_URL': reverse('index')
    }
    return render(request, 'core/portal.html', context)


@login_required
def empresa(request, slug):
    profile = Profile.objects.get(user=request.user)
    empresa = Empresa.objects.get(slug=slug)
    cargo = Cargo.objects.get(profile=profile, empresa=empresa)
    modulos = Modules.objects.filter(empresa=empresa)
    return render(request, 'core/empresa.html', {'empresa': empresa,
                                                 'modulos': modulos,
                                                 'cargo': cargo,
                                                 'VOLTAR_URL': reverse('portal')})


@login_required
def criarempresa(request):
    form = EmpresaForm()
    if request.method == 'POST':
        form = EmpresaForm(request.POST)
        if form.is_valid():
            empresa = form.save(commit=False)
            empresa.file = '/imagens/default.png'
            empresa.save()
            perfil = Profile.objects.get(user=request.user)
            Cargo.objects.create(empresa=empresa, profile=perfil, cargo='owner')

            Modules.objects.create(empresa=empresa, module='mensalidade')

            # modules_list = request.POST.getlist('modulos')
            # for modulo in modules_list:
            #     Modules.objects.create(empresa=empresa, module=modulo)
            # messages.info(request, 'Você cadastrou sua empresa, agora entre nela para começar!')
            return redirect('portal')
    return render(request, 'core/criarempresa.html', {'form': form,
                                                      'modulos': MODULOS,
                                                      'VOLTAR_URL': reverse('portal')})


def criarconta(request):
    form = AuthenticationForm()
    sign = False
    if request.method == 'POST':
        formup = SignUpForm(request.POST)
        humano = recaptcha.Recaptcha()
        if not humano.validate(request):
            sign = True
            messages.error(request, 'Recaptcha invalido, tente novamente')
            return render(request, 'core/login.html/', {'form': form,
                                                        'sign': sign,
                                                        'formup': formup})
        if formup.is_valid():
            user = formup.save()
            user.refresh_from_db()  # load the profile instance created by the signal
            user.profile.telefone = formup.cleaned_data.get('telefone')
            user.profile.picture = '/imagens/user.png'
            user.save()
            raw_password = formup.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            messages.success(request,
                             'Seja bem vindo ' + user.username + '! Você acabou de criar um perfil no Portal +GT, agora\
                              comece cadastrando sua empresa. Qualquer dúvida contate contato@maisgestaors.com.br')
            send_mail('Novo Usuário PORTAL +GT',
                      user.username + ' acaba de se cadastrar no sistema.',
                      'admin@maisgestaors.com.br', ['contato@maisgestaors.com.br'])
            return redirect('portal')
        else:
            sign = True
    else:
        formup = SignUpForm()
    return render(request, 'core/login.html', {'formup': formup,
                                               'form': form,
                                               'sign': sign})


@login_required
def sitemap(request):
    return render(request, 'core/sitemap.html')


def contato(request):
    erro = ""
    if request.method == 'POST':
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        texto = request.POST.get('texto')
        send_mail("[Contato] de " + nome, "Email: " + email + "\n" + texto, 'admin@maisgestaors.com.br',
                  ['contato@maisgestaors.com.br', 'admin@maisgestaors.com.br'])
        return render(request, 'core/contato.html/', {'erro': erro,
                                                      'nome': nome,
                                                      'email': email})


@login_required
def editarempresa(request, slug):
    empresa = Empresa.objects.get(slug=slug)
    form = EmpresaEdicaoForm(request.POST or None, instance=empresa)
    if request.method == 'POST':
        form = EmpresaEdicaoForm(request.POST, request.FILES, instance=empresa)
        # Em caso de POST, realizar o update dos dados no banco de dacos.
        if form.is_valid():
            file_object = form.cleaned_data.get('file')
            if file_object != '/imagens/default.png':
                if file_object.size > 2621440:
                    messages.error(request, 'Tamanho da foto excedido')
                    return redirect('editar_empresa', slug=slug)
                if len(request.FILES) != 0:
                    if file_object.name.split('.')[1] != 'png' and file_object.name.split('.')[1] != 'jpg':
                        # mensagem
                        messages.error(request, 'Formato da foto não permitido. Use PNG ou JPG.')
                        return redirect('editar_empresa', slug=slug)
            form.save()
            messages.success(request, 'Dados editados com sucesso')
            return redirect('portal')
    context = {
        'form': form,
        'slug': slug,
        'VOLTAR_URL': reverse('portal')
    }
    return render(request, 'core/editarempresa.html', context)


@login_required
def settings(request):
    return render(request, 'core/settings.html', {})


@login_required
def editaruser(request):
    prof = Profile.objects.get(user_id=request.user.id)
    form = UserEdicaoForm(request.POST or None, instance=prof)

    user = User.objects.get(id=request.user.id)
    form.fields['username'].initial = user.username
    form.fields['email'].initial = user.email

    if request.method == 'POST':
        form = UserEdicaoForm(request.POST, request.FILES, instance=prof)
        if form.is_valid():
            file_object = form.cleaned_data['picture']
            if file_object.size > 2621440:
                messages.error(request, 'Tamanho da foto excedido')
                return redirect('editar_user')

            if len(request.FILES) != 0:
                if file_object.name.split('.')[1] != 'png' and file_object.name.split('.')[1] != 'jpg':
                    # mensagem
                    messages.error(request, 'Formato da foto não permitido. Use PNG ou JPG.')
                    return redirect('editar_user')
            form.save()
            messages.success(request, 'Dados editados com sucesso')
            return redirect('portal')

    context = {
        'form': form
    }
    return render(request, 'core/editaruser.html', context)


@login_required
def gentoken(request):
    # resgata profile do usuário
    prof = Profile.objects.get(user_id=request.user.id)
    # verifica se o número de autenticação está zerado.
    if prof.authNumber != 0:
        messages.error(request, 'Você já tem uma solicitação de troca de senha em andamento!')
    else:
        hotp = pyotp.HOTP('base32secret3232')
        number = random.randrange(10000)
        key = hotp.at(number)

        # Save number of auth.
        prof.authNumber = number
        prof.save()
        # Envia email com o token para a autenticação.
        subject = "Confirmação troca de senha."
        url = request.build_absolute_uri(reverse('auth_token', kwargs={'token': str(key)}))
        mensagem = "Olá, acesse a seguinte URL para confirmar a troca de senha: " + url
        mfrom = 'admin@maisgestaors.com.br'
        mto = [request.user.email]
        send_mail(subject, mensagem, mfrom, mto)
        messages.warning(request, 'Um email de confirmação de troca de senha foi enviado para ' + request.user.email)
    return redirect('portal')


@login_required
def auth(request, token):
    hotp = pyotp.HOTP('base32secret3232')
    prof = Profile.objects.get(user_id=request.user.id)
    if not hotp.verify(token, prof.authNumber):
        # Cerrega o formulário pro jumento e efetua a troca de senha.
        return redirect('portal')
    else:
        # Busca profile.
        form = PasswordChangeForm(request.user)
        if request.method == 'POST':
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)

                # Recupera profile e atualiza o campo do número de troca de senha

                prof = Profile.objects.get(user_id=request.user.id)
                prof.authNumber = 0;
                prof.save()
                messages.success(request, 'Sua senha foi alterada com sucesso!')
                return redirect('settings')
            else:
                messages.error(request, 'Dados inválidos')
        return render(request, 'core/trocarsenha.html', {'form': form,
                                                         'token': token})


def sendEmail(request):
    if request.method == 'POST':
        email = request.POST.get('email_user')
        humano = recaptcha.Recaptcha()
        if humano.validate(request):
            try:
                user = User.objects.get(email=email)
                char_set = string.ascii_uppercase + string.digits + string.ascii_lowercase
                s = ''.join(random.sample(char_set * 6, 6))

                subject = "Olá!"
                mensagem = "Olá, essa é a sua nova senha: " + s
                mfrom = 'admin@maisgestaors.com.br'
                mto = [email]
                send_mail(subject, mensagem, mfrom, mto)

                user.set_password(s)
                user.save()

                messages.success(request, 'Um e-mail com a sua nova senha foi enviado para você!')
                return redirect('login')
            except ObjectDoesNotExist:
                messages.error(request, 'Não existe um usuário para esse email.')
        else:
            messages.error(request, 'Recaptcha inválido, tente novamente.')
    return render(request, 'core/sendEmail.html', {})


def profile(request):
    if request.user.id is not None:
        profile = Profile.objects.get(user=request.user.id)
        return {'profile': profile}
    else:
        return {'profile': None}


