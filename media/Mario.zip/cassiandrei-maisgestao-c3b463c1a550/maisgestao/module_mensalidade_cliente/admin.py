from django.contrib import admin

# Register your models here.
from .models import Cliente, Data, Membro, Pay, Categoria, Plano, Participante

admin.site.register(Cliente)
admin.site.register(Data)
admin.site.register(Membro)
admin.site.register(Pay)
admin.site.register(Categoria)
admin.site.register(Plano)
admin.site.register(Participante)
