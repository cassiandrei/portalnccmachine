from django.apps import AppConfig


class ModuleMensalidadeClienteConfig(AppConfig):
    name = 'module_mensalidade_cliente'
