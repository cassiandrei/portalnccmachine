from django.forms import ModelForm

from module_mensalidade_cliente.models import Categoria, Plano
from core.models import Cliente


class ClienteForm(ModelForm):
    class Meta:
        model = Cliente
        exclude = ['empresa', 'atividade', 'categorias', 'pagamento', 'created', 'status']


class EditClienteForm(ModelForm):
    class Meta:
        model = Cliente
        fields = ['nome', 'email', 'telefone']


class CategoriaForm(ModelForm):
    class Meta:
        model = Categoria
        exclude = ['empresa']


class PlanoForm(ModelForm):
    class Meta:
        model = Plano
        exclude = ['empresa']
