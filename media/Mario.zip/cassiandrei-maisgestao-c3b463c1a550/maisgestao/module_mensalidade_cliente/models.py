from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.contrib import messages
from core.models import Empresa, Cliente
from django.shortcuts import render, redirect


class Categoria(models.Model):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    nome = models.CharField(max_length=50, verbose_name='Nome',
                            help_text='Nome da Categoria, exemplo: Sertanejo, Samba, Forró, Musculação,  \
                            Judô, Inglês, Espanhol, Etc.')
    custo = models.FloatField(help_text="Valor da Mensalidade.")
    juros = models.FloatField(help_text='Taxa em PORCENTAGEM de juros composto por dia de atraso, exemplo: 1%.',
                              default=0, verbose_name='Juros diário',
                              validators=[MinValueValidator(0), MaxValueValidator(100)])

    def __str__(self):
        return self.nome


class Plano(models.Model):
    TIPOS = (('porcentagem', 'Porcentagem'),
             ('inteiro', 'Inteiro'))
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    nome = models.CharField(max_length=50, verbose_name='Nome',
                            help_text='Nome do Plano, exemplo: Duas turmas, Três Modalidades, Promoção do ano, etc')
    tipo = models.CharField(max_length=50, verbose_name='Modo de desconto', choices=TIPOS,
                            help_text='Escolha o modo de desconto: Inteiro ou porcentagem. Exemplo: 50,00 ou 25%.',
                            default='inteiro')
    desconto = models.FloatField(verbose_name='Desconto', help_text='Desconto:',
                                 validators=[MinValueValidator(0.1)])

    def __str__(self):
        return self.nome + '|' + self.empresa.nome


class Data(models.Model):
    MESES = ((1, 'Janeiro'),
             (2, 'Fevereiro'),
             (3, 'Março'),
             (4, 'Abril'),
             (5, 'Maio'),
             (6, 'Junho'),
             (7, 'Julho'),
             (8, 'Agosto'),
             (9, 'Setembro'),
             (10, 'Outubro'),
             (11, 'Novembro'),
             (12, 'Dezembro')
             )
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    mes = models.IntegerField(choices=MESES)
    ano = models.IntegerField()
    saldo = models.FloatField(default=0)
    unique_together = ('mes', 'ano')

    class Meta:
        ordering = ['-ano', 'mes']

    def __str__(self):
        return self.empresa.nome + '|' + str(self.mes) + '/' + str(self.ano)


class Pay(models.Model):
    STATUS = (
        ('pago', 'Pago'),
        ('pendente', 'Pendente'),
        ('atrasado', 'Atrasado')
    )

    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True)
    data = models.ForeignKey(Data, on_delete=models.CASCADE)
    dia = models.IntegerField()
    valor = models.FloatField()
    status = models.CharField(max_length=10, choices=STATUS)
    nome = models.CharField(max_length=75, verbose_name='Nome Cliente', null=True)

    class Meta:
        ordering = ['dia', '-data']

    def __str__(self):
        return self.empresa.nome + '|' + str(self.dia) + '/' + str(self.data.mes) + '/' + str(self.data.ano)


class MembroManager(models.Manager):
    def removermembro(self, request, categoria, empresa, cliente):
        if Pay.objects.filter(empresa=empresa, cliente=cliente, status='atrasado'):
            messages.error(request,
                           'Impossível remover cliente na categoria, porque o mesmo está com pagamento atrasado')
            return redirect('mensalidade_cliente', slug=empresa.slug, cpf=cliente.cpf)
        try:
            membro = Membro.objects.get(categoria=categoria, empresa=empresa, cliente=cliente)
            if Membro.objects.filter(empresa=empresa, cliente=cliente).count() < 2:
                cliente.status = "inativo"
                cliente.save()
                Participante.objects.filter(empresa=empresa, cliente=cliente).delete()
                Pay.objects.filter(empresa=empresa, cliente=cliente, status="pendente").delete()
            membro.delete()
        except ObjectDoesNotExist:
            pass

    def getcreate(self, request, categoria, empresa, cliente):
        if Pay.objects.filter(empresa=empresa, cliente=cliente, status='atrasado'):
            messages.error(request,
                           'Impossível adicionar cliente na categoria, porque o mesmo está com pagamento atrasado')
            return redirect('mensalidade_cliente', slug=empresa.slug, cpf=cliente.cpf)
        try:
            membro = Membro.objects.get(categoria=categoria, empresa=empresa, cliente=cliente)
        except ObjectDoesNotExist:
            membro = Membro.objects.create(categoria=categoria, empresa=empresa, cliente=cliente)
        return membro


class Membro(models.Model):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['empresa', 'categoria', 'cliente']

    objects = MembroManager()

    def __str__(self):
        return self.cliente.nome + "|" + self.categoria.nome + "|" + self.empresa.nome


class ParticipanteManager(models.Manager):

    def removerpart(self, plano, empresa, cliente):
        try:
            part = Participante.objects.get(plano=plano, empresa=empresa, cliente=cliente)
            part.delete()
        except ObjectDoesNotExist:
            pass

    def getcreate(self, plano, empresa, cliente):
        try:
            part = Participante.objects.get(plano=plano, empresa=empresa, cliente=cliente)
        except ObjectDoesNotExist:
            part = Participante.objects.create(plano=plano, empresa=empresa, cliente=cliente)
        return part

class Participante(models.Model):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)
    plano = models.ForeignKey(Plano, on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['empresa', 'plano', 'cliente']

    objects = ParticipanteManager()

    def __str__(self):
        return self.cliente.nome + "|" + self.plano.nome + "|" + self.empresa.nome
