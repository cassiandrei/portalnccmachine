from django.conf.urls import url

from module_mensalidade_cliente import views

urlpatterns = [
    url(r'^empresa/(?P<slug>\w+)/$', views.index, name='mensalidade_index'),
    url(r'^cliente/(?P<slug>\w+)/(?P<cpf>\w+)/$', views.cliente, name='mensalidade_cliente'),
    url(r'^buscacliente/(?P<slug>\w+)/$', views.cliente, name='mensalidade_buscacliente'),
    url(r'^addcliente/(?P<slug>\w+)/$', views.addcliente, name='mensalidade_addcliente'),
    url(r'^addcategoria/(?P<slug>\w+)/$', views.addcategoria, name='mensalidade_addcategoria'),
    url(r'^addplano/(?P<slug>\w+)/$', views.addplano, name='mensalidade_addplano'),
    url(r'^editcategoria/(?P<id>\w+)/$', views.editcategoria, name='mensalidade_editcategoria'),
    url(r'^editplano/(?P<id>\w+)/$', views.editplano, name='mensalidade_editplano'),
    url(r'^ativarcliente/(?P<id>\w+)/$', views.ativarcliente, name='mensalidade_ativarcliente'),
    url(r'^desativar/(?P<id>\w+)/$', views.desativar, name='mensalidade_desativar'),
    url(r'^trocarpagamento/(?P<id>\w+)/$', views.trocarpagamento, name='mensalidade_trocarpagamento'),
    url(r'^excluircat/(?P<id>\w+)/$', views.excluircat, name='mensalidade_excluircat'),
    url(r'^excluirplano/(?P<id>\w+)/$', views.excluirplano, name='mensalidade_excluirplano'),
]
