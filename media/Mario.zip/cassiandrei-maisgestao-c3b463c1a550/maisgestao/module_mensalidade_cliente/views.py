from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render, redirect, reverse
from core.models import Empresa, Profile
from module_mensalidade_cliente.forms import ClienteForm, CategoriaForm, EditClienteForm, PlanoForm
from module_mensalidade_cliente.models import Cliente, Categoria, Membro, Pay, Data, Plano, Participante
from datetime import date
from core.decorators import secure_slug


@login_required
@secure_slug
def index(request, slug):
    form = CategoriaForm()
    formplan = PlanoForm()
    empresa = Empresa.objects.get(slug=slug)
    clientes = Cliente.objects.filter(empresa=empresa)
    inativos = clientes.filter(status='inativo')
    lista_datas = Data.objects.filter(empresa=empresa)
    pagamentos = Pay.objects.filter(empresa=empresa)
    membros = Membro.objects.filter(empresa=empresa)
    planos = Plano.objects.filter(empresa=empresa)
    for pagamento in pagamentos:
        if pagamento.status == 'pendente' or pagamento.status == 'atrasado':
            hoje = date.today()
            dias = date(day=pagamento.dia, month=pagamento.data.mes, year=pagamento.data.ano) - hoje
            if dias.days < 0:
                valor = 0.0
                pagamento.status = 'atrasado'
                cat_pag = Membro.objects.filter(empresa=empresa, cliente=pagamento.cliente)
                for cat in cat_pag:
                    valor += cat.categoria.custo * (((cat.categoria.juros / 100) + 1) ** abs(dias.days))
                pagamento.valor = valor
                promos = Participante.objects.filter(empresa=empresa, cliente=pagamento.cliente)
                for promo in promos:
                    if promo.plano.tipo == 'inteiro':
                        pagamento.valor -= promo.plano.desconto
                    else:
                        pagamento.valor *= (1 - (promo.plano.desconto / 100))
            else:
                pagamento.status = 'pendente'
            pagamento.save()
    pendentes = Pay.objects.filter(empresa=empresa).exclude(status='pago')
    categorias = Categoria.objects.filter(empresa=empresa)
    return render(request, 'module_mensalidade_clientes/index.html', {'lista_datas': lista_datas,
                                                                      'clientes': clientes,
                                                                      'slug': slug,
                                                                      'form': form,
                                                                      'formplan': formplan,
                                                                      'categorias': categorias,
                                                                      'membros': membros,
                                                                      'planos': planos,
                                                                      'pagamentos': pagamentos,
                                                                      'pendentes': pendentes,
                                                                      'inativos': inativos,
                                                                      'VOLTAR_URL': reverse('empresa',
                                                                                            kwargs={'slug': slug})
                                                                      })


@login_required
def editcategoria(request, id):
    categoria = Categoria.objects.get(id=id)
    form = CategoriaForm(request.POST or None, instance=categoria)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Categoria editada com sucesso')
            return redirect('mensalidade_index', slug=categoria.empresa.slug)
    return render(request, 'module_mensalidade_clientes/editcategoria.html', {'form': form,
                                                                              'id': id,
                                                                              'VOLTAR_URL': reverse('mensalidade_index',
                                                                                                    kwargs={
                                                                                                        'slug': categoria.empresa.slug})
                                                                              })


@login_required
def editplano(request, id):
    plano = Plano.objects.get(id=id)
    form = PlanoForm(request.POST or None, instance=plano)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Plano editado com sucesso')
            return redirect('mensalidade_index', slug=plano.empresa.slug)
    return render(request, 'module_mensalidade_clientes/editplano.html', {'form': form,
                                                                          'id': id,
                                                                          'VOLTAR_URL': reverse('mensalidade_index',
                                                                                                kwargs={
                                                                                                    'slug': plano.empresa.slug})
                                                                          })


@login_required
@secure_slug
def addcategoria(request, slug):
    form = CategoriaForm(request.POST)
    empresa = Empresa.objects.get(slug=slug)
    if form.is_valid():
        categoria = form.save(commit=False)
        categoria.empresa = empresa
        categoria.save()
    return redirect('mensalidade_index', slug=slug)


@login_required
@secure_slug
def addplano(request, slug):
    form = PlanoForm(request.POST)
    empresa = Empresa.objects.get(slug=slug)
    if form.is_valid():
        plano = form.save(commit=False)
        plano.empresa = empresa
        plano.save()
    return redirect('mensalidade_index', slug=slug)


@login_required
@secure_slug
def addcliente(request, slug):
    empresa = Empresa.objects.get(slug=slug)
    categorias = Categoria.objects.filter(empresa=empresa)
    planos = Plano.objects.filter(empresa=empresa)
    form = ClienteForm()
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            custo = 0
            cliente = form.save(commit=False)
            cliente.empresa = empresa
            try:
                Cliente.objects.get(empresa=empresa, cpf=request.POST['cpf'])
                messages.error(request, "Cliente já existe")
                return redirect('mensalidade_addcliente', slug=slug)
            except ObjectDoesNotExist:
                cliente.save()
            for categoria in categorias:
                if request.POST.get('{}'.format(categoria.id)):
                    Membro.objects.create(empresa=empresa, categoria=categoria, cliente=cliente)
                    custo += categoria.custo
            for plano in planos:
                if request.POST.get('p' + '{}'.format(plano.id)):
                    Participante.objects.getcreate(empresa=empresa, plano=plano, cliente=cliente)
                    if plano.tipo == 'inteiro':
                        custo -= plano.desconto
                    else:
                        custo = custo * (1 - (plano.desconto / 100))
            primeiro_pag = request.POST['primeiro_pag'].split('/')
            try:
                datafuturo = Data.objects.get(empresa=empresa, mes=int(primeiro_pag[0]), ano=int(primeiro_pag[2]))
                datafuturo.save()
            except ObjectDoesNotExist:
                datafuturo = Data.objects.create(empresa=empresa, mes=int(primeiro_pag[0]), ano=int(primeiro_pag[2]))
            Pay.objects.create(empresa=empresa, cliente=cliente, valor=custo, status='pendente',
                               data=datafuturo,
                               dia=primeiro_pag[1], nome=cliente.nome)
            cliente.save()
            return redirect('mensalidade_index', slug=slug)
        else:
            return redirect('mensalidade_addcliente', slug=slug)
    return render(request, 'module_mensalidade_clientes/addcliente.html', {'form': form,
                                                                           'slug': slug,
                                                                           'categorias': categorias,
                                                                           'planos': planos,
                                                                           'VOLTAR_URL': reverse('mensalidade_index',
                                                                                                 kwargs={
                                                                                                     'slug': slug})})


@login_required
def excluircat(request, id):
    categoria = Categoria.objects.get(id=id)
    empresa = categoria.empresa
    # puxar todos clientes da empresa na categoria e ver se um eh atrasado
    # MELHORAR
    membros = Membro.objects.filter(empresa=empresa, categoria=categoria)
    for membro in membros:
        if Pay.objects.filter(cliente=membro.cliente, status='atrasado'):
            messages.error(request,
                           'Impossível excluir categoria, porque existem pagamentos ATRASADOS de clientes que estão nessa categoria')
            return redirect('mensalidade_editcategoria', id=id)
    for membro in membros:
        Membro.objects.removermembro(request=request, categoria=categoria, empresa=empresa, cliente=membro.cliente)
    categoria.delete()
    messages.success(request, 'Categoria removida com sucesso')
    return redirect('mensalidade_index', slug=empresa.slug)


@login_required
def excluirplano(request, id):
    plano = Plano.objects.get(id=id)
    empresa = plano.empresa
    participantes = Participante.objects.filter(empresa=empresa, plano=plano)
    for participante in participantes:
        if Pay.objects.filter(cliente=participante.cliente, status='atrasado'):
            messages.error(request,
                           'Impossível excluir plano, porque existem pagamentos ATRASADOS de clientes que estão nesse plano')
            return redirect('mensalidade_editplano', id=id)
    Participante.objects.filter(plano=plano, empresa=empresa).delete()
    plano.delete()
    messages.success(request, 'Plano removido com sucesso')
    return redirect('mensalidade_index', slug=empresa.slug)


@login_required
def ativarcliente(request, id):
    cliente = Cliente.objects.get(id=id)
    empresa = cliente.empresa
    planos = Plano.objects.filter(empresa=empresa)
    if request.method == 'POST':
        custo = 0
        categorias = Categoria.objects.filter(empresa=empresa)
        for categoria in categorias:
            if request.POST.get(str(categoria.id)):
                Membro.objects.getcreate(request=request, categoria=categoria, empresa=empresa, cliente=cliente)
                custo += categoria.custo
        for plano in planos:
            if request.POST.get('p' + str(plano.id)):
                Participante.objects.getcreate(empresa=empresa, cliente=cliente, plano=plano)
                if plano.tipo == 'inteiro':
                    custo -= plano.desconto
                else:
                    custo = custo * (1 - (plano.desconto / 100))
        primeiro_pag = request.POST['ativar_data'].split('/')
        try:
            datafuturo = Data.objects.get(empresa=empresa, mes=int(primeiro_pag[0]), ano=int(primeiro_pag[2]))
            datafuturo.save()
        except ObjectDoesNotExist:
            datafuturo = Data.objects.create(empresa=empresa, mes=int(primeiro_pag[0]), ano=int(primeiro_pag[2]))
        Pay.objects.create(empresa=empresa, cliente=cliente, valor=custo, status='pendente',
                           data=datafuturo,
                           dia=primeiro_pag[1], nome=cliente.nome)
        cliente.status = 'ativo'
        cliente.save()
        messages.success(request, 'Cliente reativado com sucesso')
        # TROCAR PARA REDIRECT MENSALIDADE CLIENTE
    return redirect('mensalidade_cliente', slug=empresa.slug, cpf=cliente.cpf)


@login_required
def trocarpagamento(request, id):
    pagamento = Pay.objects.get(id=id)
    if request.method == 'POST':
        data = request.POST['datapay'].split('/')
        pagamento.dia = int(data[1])
        try:
            data = Data.objects.get(empresa=pagamento.cliente.empresa, mes=int(data[0]), ano=int(data[2]))
        except ObjectDoesNotExist:
            data = Data.objects.create(empresa=pagamento.cliente.empresa, mes=int(data[0]), ano=int(data[2]))
        pagamento.data = data
        pagamento.save()
        messages.success(request, 'Pagamento alterado com sucesso')
    return redirect('mensalidade_index', slug=pagamento.cliente.empresa.slug)


@login_required
def desativar(request, id):
    cliente = Cliente.objects.get(id=id)
    pagamento = Pay.objects.filter(empresa=cliente.empresa, cliente=cliente).exclude(status='pago')[0]
    if pagamento.status == 'atrasado':
        messages.error(request, 'Não é possível desativar cliente com pagamento Atrasado.')
    else:
        membros = Membro.objects.filter(empresa=cliente.empresa, cliente=cliente)
        for membro in membros:
            Membro.objects.removermembro(request=request, categoria=membro.categoria, empresa=cliente.empresa,
                                         cliente=cliente)
        messages.success(request, 'Cliente Inativo com sucesso')
    return redirect('mensalidade_cliente', slug=cliente.empresa.slug, cpf=cliente.cpf)


@secure_slug
@login_required
def buscacliente(request, slug):
    return redirect('mensalidade_cliente', slug=slug, cpf=request.POST['clienteform'])


@secure_slug
@login_required
def cliente(request, slug, cpf=None):
    empresa = Empresa.objects.get(slug=slug)
    if cpf:
        cliente = Cliente.objects.get(empresa=empresa, cpf=cpf)
    else:
        cliente = Cliente.objects.get(empresa=empresa, cpf=request.POST['clienteform'])
    # DADOS DA EMPRESA
    categorias = Categoria.objects.filter(empresa=empresa)
    planos = Plano.objects.filter(empresa=empresa)
    # PAGAMENTOS
    pagamentos = Pay.objects.filter(empresa=empresa, cliente=cliente).exclude(status='pago')
    # FORMULARIOS
    formcliente = EditClienteForm(instance=cliente)
    if request.POST.get('gerenciar'):
        formcliente = EditClienteForm(request.POST, instance=cliente)
        if formcliente.is_valid():
            for categoria in categorias:
                if request.POST.get(str(categoria.id)):
                    Membro.objects.getcreate(request=request, categoria=categoria, empresa=empresa, cliente=cliente)
                else:
                    Membro.objects.removermembro(request=request, categoria=categoria, empresa=empresa, cliente=cliente)
            if cliente.status != 'inativo':
                for plano in planos:
                    if request.POST.get('p' + str(plano.id)):
                        Participante.objects.getcreate(plano=plano, empresa=empresa, cliente=cliente)
                    else:
                        Participante.objects.removerpart(plano=plano, empresa=empresa, cliente=cliente)
            formcliente.save()
            messages.success(request, 'Dados alterados com sucesso')
    # LISTA DE CATEGORIAS
    lista_membros = []
    membros = Membro.objects.filter(empresa=empresa, cliente=cliente)
    for membro in membros:
        lista_membros.append(membro.categoria.nome)
    # LISTA DE PARTICIPANTES
    lista_participantes = []
    participantes = Participante.objects.filter(empresa=empresa, cliente=cliente)
    for participante in participantes:
        lista_participantes.append(participante.plano.nome)
    # EXCLUIR CLIENTE
    if request.POST.get('desvincular'):
        pagamentos.delete()
        cliente.delete()
        messages.success(request, 'Cliente Excluído com sucesso')
        return redirect('mensalidade_index', slug=empresa.slug)
    # TRANCAR
    if request.POST.get('trancar'):
        data = request.POST['data-trancar'].split('/')
        hoje = date.today()
        dias = date(year=int(data[2]), month=int(data[0]), day=int(data[1])) - date(year=hoje.year,
                                                                                    month=hoje.month, day=hoje.day)
        if dias.days > 0:
            for pagamento in pagamentos:
                nova_data = date(day=pagamento.dia, month=pagamento.data.mes, year=pagamento.data.ano)
                nova_data = date.fromordinal(nova_data.toordinal() + dias.days)
                pagamento.dia = nova_data.day
                try:
                    pagamento.data = Data.objects.get(empresa=empresa, mes=nova_data.month, ano=nova_data.year)
                except ObjectDoesNotExist:
                    pagamento.data = Data.objects.create(empresa=empresa, mes=nova_data.month, ano=nova_data.year)
                pagamento.save()
                messages.success(request, 'Pagamento alterado com sucesso de acordo com o Trancamento do cliente')
        else:
            messages.error(request, 'Trancamento invalido, selecione uma data superior à hoje.')
    # EFETUAR PAGAMENTO
    if request.POST.get('pagamento'):
        # Registrando pagamento no saldo MES do pagamento
        fatura = Pay.objects.get(id=request.POST.get('pagamentoid'))
        fatura.status = 'pago'
        fatura.data.saldo += float(request.POST['recebido'])
        empresa.saldo += float(request.POST['recebido'])
        empresa.save()
        fatura.save()
        fatura.data.save()
        # Gerando proximo pagamento
        # Gerando custo das categorias
        custo = 0
        for membro in membros:
            custo += membro.categoria.custo
        for plano in planos:
            if plano.tipo == 'inteiro':
                custo -= plano.desconto
            else:
                custo = custo * (1 - (plano.desconto / 100))
        # calculando diferenca
        multa = float(request.POST['multa'])
        desconto = float(request.POST['desconto'])
        recebido = float(request.POST['recebido'])
        diferenca = fatura.valor - recebido + desconto + multa
        hoje = date.today()
        dif_dias = hoje - date(day=fatura.dia, month=fatura.data.mes, year=fatura.data.ano)
        if dif_dias.days > 0:  # ATRASADO
            try:
                if fatura.data.mes < 12:
                    data = Data.objects.get(empresa=empresa, mes=hoje.month + 1, ano=hoje.year)
                else:
                    data = Data.objects.get(empresa=empresa, mes=1, ano=hoje.year + 1)
            except ObjectDoesNotExist:
                if fatura.data.mes < 12:
                    data = Data.objects.create(empresa=empresa, mes=hoje.month + 1, ano=hoje.year)
                else:
                    data = Data.objects.create(empresa=empresa, mes=1, ano=hoje.year + 1)
        else:  # ADIANTADO
            try:
                if fatura.data.mes < 12:
                    data = Data.objects.get(empresa=empresa, mes=fatura.data.mes + 1, ano=fatura.data.ano)
                else:
                    data = Data.objects.get(empresa=empresa, mes=1, ano=fatura.data.ano + 1)
            except ObjectDoesNotExist:
                if fatura.data.mes < 12:
                    data = Data.objects.create(empresa=empresa, mes=fatura.data.mes + 1, ano=fatura.data.ano)
                else:
                    data = Data.objects.create(empresa=empresa, mes=1, ano=fatura.data.ano + 1)
        if cliente.status != 'inativo':
            Pay.objects.create(empresa=empresa, dia=fatura.dia, data=data, valor=custo + diferenca,
                               status='pendente',
                               cliente=cliente, nome=cliente.nome)
            messages.success(request, 'Pagamento Efetuado com sucesso, o próximo pagamento de '
                             + cliente.nome + ' foi gerado')
            return redirect('mensalidade_index', slug=empresa.slug)
        else:
            messages.error(request, 'O cliente está INATIVO e não foi gerado novo pagamento')
    return render(request, 'module_mensalidade_clientes/cliente.html', {'cliente': cliente,
                                                                        'planos': planos,
                                                                        'formcliente': formcliente,
                                                                        'categorias': categorias,
                                                                        'pagamentos': pagamentos,
                                                                        'membros': lista_membros,
                                                                        'participantes': lista_participantes,
                                                                        'VOLTAR_URL': reverse('mensalidade_index',
                                                                                              kwargs={
                                                                                                  'slug': empresa.slug})
                                                                        })
