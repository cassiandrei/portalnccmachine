#ifndef CARRO_H
#define CARRO_H
#include "glCanvas2d.h"

class carro
{
    int tam;
    float dirx;
    float diry;
    float posx;
    float posy;
    float vel;
    float vx[3];
    float vy[3];
    int setvelo;
    public:
        carro(int tam, float x, float y);
        void carro_desenha(Canvas2D* canvas);
        void carro_direcao(int x);
        void carro_velo(int x);
        void carro_setvelo(int x);
};

#endif // CARRO_H
